/*package masterData;

import checkoutServiceDomain.payments.*;

public class CheckoutPaymentDetails {

	private static Payment paymentDetails = new Payment();
	private static BillingDetails billingDetails = new BillingDetails();
	private static BillingAddress billingAddress = new BillingAddress();
	private static Card card = new Card();
	private static RiskDetails riskDetails = new RiskDetails();
	
	public CheckoutPaymentDetails(){
		
		paymentDetails.setFee("3.00");
		paymentDetails.setMerchantUrl("http://eurostar.com");
		
		billingDetails.setName("Test User");
		billingAddress.setAddressLine1("Times House");
		billingAddress.setAddressLine2("Bravington Walk");
		billingAddress.setCity("London");
		billingAddress.setCountry("London");
		billingAddress.setPostCode("N1 9AW");
		billingDetails.setBillingAddress(billingAddress);
		paymentDetails.setBillingDetails(billingDetails);
		
		//card.setCardType("VISA");
		//paymentDetails.setCard(card);
		
		riskDetails.setBrowserLanguage("Chrome xxx");
		riskDetails.setIpAddress("127.0.0.1");
		riskDetails.setUserMachineId("machine x");
		riskDetails.setSessionId("test-be-session");
		paymentDetails.setRiskDetails(riskDetails);
		
	}
	
	public static Payment getCheckoutPaymentDetails(){
		return paymentDetails;
	}	
	
}*/
