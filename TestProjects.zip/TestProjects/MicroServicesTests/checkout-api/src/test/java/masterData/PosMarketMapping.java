package masterData;

public class PosMarketMapping {

	public static String getMarketFromPos(String pos){
		
		switch(pos)
		{
			case "GBZXB":
				return "fr";
			default:
				return "en";
		}

	}
}
