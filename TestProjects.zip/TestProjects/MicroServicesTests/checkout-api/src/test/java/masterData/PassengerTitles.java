package masterData;

import java.util.Random;

public class PassengerTitles {
 
	private static String[] titles = {"Mr", "Miss", "Mrs", "Ms"};
	
	public static String getPassengerTitle(){

		Random random = new Random();
		return titles[random.nextInt(titles.length)];
	
	}
}
