package masterData;

public class PassengerNames {
	
	private static final String[] firstName = {"John", "Jane", "Joanne", "Paula", "Chris", "Peter", "Michael", "Mandy", "Amy"};
	private static final String[] lastName = {"Smith", "Doe", "Halls", "Green", "Brown", "Jones", "Evans", "Wood", "Hill"};

	public static String getFirstName(int paxIndex){
		
		return firstName[paxIndex];		
	}
		
	public static String getLastName(int paxIndex){
			
		return lastName[paxIndex];
	}
}
