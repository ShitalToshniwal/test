package masterData;

public class ClassOfAccom {

	public static String getClassOfAccomCode(String classOfAccom){

		String classOfAccomCode = "";
		
		switch(classOfAccom)
		{
			case "Standard":
				classOfAccomCode = "B";
				break;
			case "StandardPremier":
				classOfAccomCode = "H";
				break;
			case "BusinessPremier":
				classOfAccomCode = "A";
				break;
			default:
					System.out.println("Invalid class of accommodation passed: " + classOfAccom);
		}
		
		return classOfAccomCode;
	}
}
