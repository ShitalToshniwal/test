package masterData;

public class PassengerAges {
	
	private final static int adultAge = 30;
	private final static int youthAge = 15;
	private final static int childAge = 5;
	
	public static int getAdultAge() {
		return adultAge;
	}
	public static int getYouthAge() {
		return youthAge;
	}
	public static int getChildAge() {
		return childAge;
	}

}
