package requestHolders;

public class CheckoutRequestProperties {

	public static String classOfAccomCode;
	public static String market;
	public static String cartId;
	public static int numOfAdults;
	public static int numOfYouths;
	public static int numOfChildren;
	public static int totalPassengers;

	public static String getClassOfAccomCode() {
		return classOfAccomCode;
	}

	public static void setClassOfAccomCode(String classOfAccomCode) {
		CheckoutRequestProperties.classOfAccomCode = classOfAccomCode;
	}

	public static String getCartId() {
		return cartId;
	}

	public static void setCartId(String cartId) {
		CheckoutRequestProperties.cartId = cartId;
	}

	public static String getMarket() {
		return market;
	}

	public static void setMarket(String market) {
		CheckoutRequestProperties.market = market;
	}

	public static int getNumOfAdults() {
		return numOfAdults;
	}

	public static void setNumOfAdults(int numOfAdults) {
		CheckoutRequestProperties.numOfAdults = numOfAdults;
	}

	public static int getNumOfYouths() {
		return numOfYouths;
	}

	public static void setNumOfYouths(int numOfYouths) {
		CheckoutRequestProperties.numOfYouths = numOfYouths;
	}

	public static int getNumOfChildren() {
		return numOfChildren;
	}

	public static void setNumOfChildren(int numOfChildren) {
		CheckoutRequestProperties.numOfChildren = numOfChildren;
	}

	public static int getTotalPassengers() {
		return totalPassengers;
	}

	public static void setTotalPassengers() {
		CheckoutRequestProperties.totalPassengers = getNumOfAdults() + getNumOfYouths() + getNumOfChildren();
	}
	
	
}
