package requestHolders;

public class DatacashRequestProperties {

	public static String hpsUrl;
	public static String HPS_SessionId;
	public static String Cookie;
	public static String card_number;
	public static String exp_month;
	public static String exp_year;
	public static String cv2_number;
	
	public static String getHpsUrl() {
		return hpsUrl;
	}

	public static void setHpsUrl(String hpsUrl) {
		DatacashRequestProperties.hpsUrl = hpsUrl;
	}

	public static String getHPS_SessionId() {
		return HPS_SessionId;
	}
	
	public static void setHPS_SessionId(String hPS_SessionId) {
		HPS_SessionId = hPS_SessionId;
	}
	
	public static String getCookie() {
		return Cookie;
	}
	
	public static void setCookie(String cookie) {
		Cookie = cookie;
	}
	
	public static String getCard_number() {
		return card_number;
	}
	
	public static void setCard_number(String card_number) {
		DatacashRequestProperties.card_number = card_number;
	}
	
	public static String getExp_month() {
		return exp_month;
	}
	
	public static void setExp_month(String exp_month) {
		DatacashRequestProperties.exp_month = exp_month;
	}
	
	public static String getExp_year() {
		return exp_year;
	}
	
	public static void setExp_year(String exp_year) {
		DatacashRequestProperties.exp_year = exp_year;
	}
	
	public static String getCv2_number() {
		return cv2_number;
	}
	
	public static void setCv2_number(String cv2_number) {
		DatacashRequestProperties.cv2_number = cv2_number;
	}
	
	
	
}
