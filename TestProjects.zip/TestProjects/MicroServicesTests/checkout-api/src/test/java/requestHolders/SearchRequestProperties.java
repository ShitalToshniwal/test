package requestHolders;

public class SearchRequestProperties {

	public static int origin;
	public static int destination;
	public static String outboundDate;
	public static String inboundDate;
	public static int numOfAdults;
	public static int numOfYouths;
	public static int numOfChildren;
	public static String youthAge;
	public static String childAge;
	
	public static int getOrigin() {
		return origin;
	}
	
	public static void setOrigin(int origin) {
		SearchRequestProperties.origin = origin;
	}
	
	public static int getDestination() {
		return destination;
	}
	
	public static void setDestination(int destination) {
		SearchRequestProperties.destination = destination;
	}
	
	public static String getOutboundDate() {
		return outboundDate;
	}
	
	public static void setOutboundDate(String outboundDate) {
		SearchRequestProperties.outboundDate = outboundDate;
	}
	
	public static String getInboundDate() {
		return inboundDate;
	}
	
	public static void setInboundDate(String inboundDate) {
		SearchRequestProperties.inboundDate = inboundDate;
	}
	
	public static int getNumOfAdults() {
		return numOfAdults;
	}
	
	public static void setNumOfAdults(int numOfAdults) {
		SearchRequestProperties.numOfAdults = numOfAdults;
	}
	
	public static int getNumOfYouths() {
		return numOfYouths;
	}
	
	public static void setNumOfYouths(int numOfYouths) {
		SearchRequestProperties.numOfYouths = numOfYouths;
	}
	
	public static int getNumOfChildren() {
		return numOfChildren;
	}
	
	public static void setNumOfChildren(int numOfChildren) {
		SearchRequestProperties.numOfChildren = numOfChildren;
	}
	
	public static String getYouthAge() {
		return youthAge;
	}
	
	public static void setYouthAge(String youthAge) {
		SearchRequestProperties.youthAge = youthAge;
	}
	
	public static String getChildAge() {
		return childAge;
	}
	
	public static void setChildAge(String childAge) {
		SearchRequestProperties.childAge = childAge;
	}
	
}
