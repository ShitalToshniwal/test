package stepDefinition.commonSteps;

import static com.jayway.restassured.RestAssured.given;

import java.lang.reflect.Array;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.Response;

import checkoutServiceDomain.payments.BillingAddress;
import checkoutServiceDomain.payments.BillingDetails;
import checkoutServiceDomain.payments.Card;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import library.BaseClass;
import library.FieldExtractor;
import requestHolders.CheckoutRequestProperties;
import responseHolders.CreateCartResponseHolder;
import stepDefinition.CheckoutCartSteps;


public class CommonSteps {

	@Given("^The test case name is: ? (.*)$")
	public void createLogForTestcase(String tcName) throws Throwable {
		System.out.println("Test case: " + tcName);
	}
	
	@Given("^I extract value of \"([^\"]*)\" fields from \"([^\"]*)\" response$")
	public void extractValueFromResponse(String fields, String requestEndpoint) throws Throwable {

		String[] arrFields = fields.split(",");
		
		for(int i = 0; i < arrFields.length; i++){
			switch(arrFields[i].trim()){
				case "cartId":
					String value = CreateCartResponseHolder.response.then().extract().path(arrFields[i]);
					System.out.println(value);
					requestHolders.CheckoutRequestProperties.setCartId(value);
					break;
				case "sessionId":
					String sessionId = CreateCartResponseHolder.response.then().extract().path("payment." + arrFields[i]);
					System.out.println("sessionId:" + sessionId);
					requestHolders.DatacashRequestProperties.setHPS_SessionId(sessionId);
					break;
				default:
					break;
					
			}
		}
		/*String val = FieldExtractor.extractValueOfFieldFromResponse(fieldPath);
		System.out.println(val);
		requestHolders.CheckoutRequestProperties.setCartId(val);*/
		
	}

	@Given("^I post payment card details via Datacash iframe for card type: ? (.*)$")
	public void sendDataToDatacashIframe(String cardType) throws Exception{
		
		Card tmpCard = new Card();
		tmpCard.setCardType(cardType);
		CheckoutCartSteps.newPayment.setCard(tmpCard);
		CheckoutCartSteps.newCheckoutCart.setPayment(CheckoutCartSteps.newPayment);
		
		String sessionId = requestHolders.DatacashRequestProperties.getHPS_SessionId(); 
		Response iFrameResp = given().log().all().
							queryParam("HPS_SessionID", sessionId).
							queryParam("Cookie", "JSESSIONID=" + sessionId).
							queryParam("card_number", "6759000000000000").
							queryParam("exp_month", "01").
							queryParam("exp_year", "2017").
							queryParam("cv2_number", "123").
							queryParam("action", "confirm").
							queryParam("continue", "Continue").
							when().
							content(ContentType.JSON).
							post(BaseClass.datacashURL);
		
		System.out.println("datacash results-------------");
		System.out.println(iFrameResp.asString());
		System.out.println(iFrameResp.getStatusCode());
	
	}
	
	@Given("^The Contact Details are: \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void setContactDetails(String title, String firstName, String lastName, String email, String countryCode, String phoneNumber) throws Throwable {
	    
		CheckoutCartSteps.newContactDetails.setTitle(title);
		CheckoutCartSteps.newContactDetails.setFirstName(firstName);
		CheckoutCartSteps.newContactDetails.setLastName(lastName);
		CheckoutCartSteps.newContactDetails.setEmail(email);
		CheckoutCartSteps.newContactDetails.setPhoneCountryCode(countryCode);
		CheckoutCartSteps.newContactDetails.setPhoneNumber(phoneNumber);
		
		CheckoutCartSteps.newCheckoutCart.setContactDetails(CheckoutCartSteps.newContactDetails);
	}

	@Given("^The Billing Details are: \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void setBillingDetails(String nameOnCC, String addressLine1, String addressLine2, String city, String countryCode, String postCode) throws Throwable {
		BillingDetails newBillingDetails = new BillingDetails();
		newBillingDetails.setName(nameOnCC);
		
		BillingAddress newBillingAddress = new BillingAddress();
		newBillingAddress.setAddressLine1(addressLine1);
		newBillingAddress.setAddressLine2(addressLine2);
		newBillingAddress.setCity(city);
		newBillingAddress.setCountry(countryCode);
		newBillingAddress.setPostCode(postCode);
		newBillingDetails.setBillingAddress(newBillingAddress);
		
		CheckoutCartSteps.newPayment.setBillingDetails(newBillingDetails);
	}

}
