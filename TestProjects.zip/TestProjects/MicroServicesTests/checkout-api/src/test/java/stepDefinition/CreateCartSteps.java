package stepDefinition;

import static com.jayway.restassured.RestAssured.*;

import com.fasterxml.jackson.databind.ObjectMapper;
//import com.jayway.restassured.RestAssured;
import com.jayway.restassured.http.ContentType;
//import com.jayway.restassured.response.*;
//import com.jayway.restassured.path.json.JsonPath;
import com.jayway.restassured.response.Response;

import cucumber.api.java.en.Given;
//import cucumber.api.java.Before;
import cucumber.api.java.en.When;
import library.BaseClass;
import responseHolders.CreateCartResponseHolder;
import stepDefinition.commonSteps.RequestStepsToSetParams;

import java.io.File;

import checkoutServiceDomain.*;
import checkoutServiceDomain.payments.*;


//import org.hamcrest.Matchers.*;

public class CreateCartSteps { //extends BaseClass{
	
	public static String jsonRequestsFolder; // = "CreateCart";
	private static Response resp;
	
	/* Using domain model to create an object for json request*/

	private static NewCart newCart = new NewCart();
	private static Amount newAmount = new Amount();
	private PaymentSetup newPaymentSetup = new PaymentSetup();
	private ObjectMapper objMapper = new ObjectMapper();
	
	@Given("^I build create cart request using \"([^\"]*)\" with value: ? (.*)")
	public void buildRequest_CreateCart(String fieldName, String fieldValue) throws Throwable {
		
		System.out.println("fieldName: " + fieldName);
		System.out.println("fieldValue: " + fieldValue);

		String[] arrfieldNames = fieldName.split("\\.");
		for(int i = 0; i < arrfieldNames.length; i++)
		{
			//System.out.println(arrfieldNames[i]);
			switch(arrfieldNames[i])
			{
				case "pageSetId":
					newPaymentSetup.setPageSetId(fieldValue);
					break;
				case "currency":
					newAmount.setCurrency(fieldValue);
					break;
				case "value":
					newAmount.setValue(Double.valueOf(fieldValue));
					break;
			}
		}
		
	//Payment zzz =	objMapper.readValue(new File(),  Payment.class);
		newCart.setAmount(newAmount);
		newCart.setPaymentSetup(newPaymentSetup);
		//System.out.println(objMapper.writeValueAsString(newCart));
		
		//newAmount.setCurrency("GBP");
		//newAmount.setValue(100.9);
		//newCart.setAmount(newAmount);
		
		//newPaymentSetup.setExpiryUrl("http://eurostar.com/pay_expiry.html");
		//newPaymentSetup.setReturnUrl("http://eurostar.com/pay_return.html");
		/*newPaymentSetup.setPageSetId("1234");
		newCart.setPaymentSetup(newPaymentSetup);
		
		ObjectMapper objMapper = new ObjectMapper();
		System.out.println(objMapper.writeValueAsString(newCart));
		
		resp = given().
				queryParam("pos", RestRequestSteps.getPos()).
				header("cid", RestRequestSteps.getCid()).
				body(newCart).
				when().
				contentType(ContentType.JSON).
				post("/carts");
		
		System.out.println(resp.asString());*/
	}

	@When("^I create a new cart$")
	public static void executeCreateCart() throws Throwable {
		
		ObjectMapper objMapper = new ObjectMapper();
		if(newAmount.getCurrency() == null)
		{
			System.out.println("currency is null");
			System.out.println(objMapper.writeValueAsString(newCart));
		}
		
		//System.out.println(objMapper.writeValueAsString(newCart));
		
		resp = given().
				queryParam("pos", RequestStepsToSetParams.getPos()).
				header("cid", RequestStepsToSetParams.getCid()).
				body(newCart).
				when().
				contentType(ContentType.JSON).
				post("/carts");
		
		CreateCartResponseHolder.setResponse(resp);
		//System.out.println(resp.asString());
	}
	
	@When("^I create a new cart with: ? (.*)$")
	public void executeCreateCartWithJson(String jsonFileName) throws Throwable {
		
		String jsonFilePath = BaseClass.jsonRequestsFolderPath + jsonRequestsFolder + "\\" + jsonFileName;
		//System.out.println(jsonFilePath);
		File jsonFile = new File(jsonFilePath);

		if(RequestStepsToSetParams.getCid().equals("") && RequestStepsToSetParams.getPos().equals(""))
			resp = given().
			body(jsonFile).
			when().
			contentType(ContentType.JSON).
			post("/carts");
		
		if(RequestStepsToSetParams.getCid().equals("") == true && RequestStepsToSetParams.getPos().equals("") == false)
			resp = given().
			queryParam("pos", RequestStepsToSetParams.getPos()).
			body(jsonFile).
			when().
			contentType(ContentType.JSON).
			post("/carts");
		
		if(RequestStepsToSetParams.getPos().equals("") == true && RequestStepsToSetParams.getCid().equals("") == false)
			resp = given().
			header("cid", RequestStepsToSetParams.getCid()).
			body(jsonFile).
			when().
			contentType(ContentType.JSON).
			post("/carts");
			
		if(RequestStepsToSetParams.getPos().equals("") == false && RequestStepsToSetParams.getCid().equals("") == false)
			resp = given().
			header("cid", RequestStepsToSetParams.getCid()).
			queryParam("pos", RequestStepsToSetParams.getPos()).
			body(jsonFile).
			when().
			contentType(ContentType.JSON).
			post("/carts");

		CreateCartResponseHolder.setResponse(resp);

	}


}
