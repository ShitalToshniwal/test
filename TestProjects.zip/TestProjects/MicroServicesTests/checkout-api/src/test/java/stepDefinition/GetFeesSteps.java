package stepDefinition;

import static com.jayway.restassured.RestAssured.given;
import com.jayway.restassured.response.Response;

import cucumber.api.java.en.When;
import responseHolders.CreateCartResponseHolder;
import stepDefinition.commonSteps.RequestStepsToSetParams;

public class GetFeesSteps {
	
	private Response resp;

	@When("^I execute get credit card fees request$")
	public void executeGetFeesRequest() throws Throwable {

		
		if(RequestStepsToSetParams.getCid().equals("") && RequestStepsToSetParams.getPos().equals(""))
			resp = given().
				when().
				get("/fees");
		
		if(RequestStepsToSetParams.getCid().equals("") == true && RequestStepsToSetParams.getPos().equals("") == false)
			resp = given().
				queryParam("pos", RequestStepsToSetParams.getPos()).
				when().
				get("/fees");
		
		if(RequestStepsToSetParams.getPos().equals("") == true && RequestStepsToSetParams.getCid().equals("") == false)
			resp = given().
				header("cid", RequestStepsToSetParams.getCid()).
				when().
				get("/fees");
			
		if(RequestStepsToSetParams.getPos().equals("") == false && RequestStepsToSetParams.getCid().equals("") == false)
			resp = given().
				header("cid", RequestStepsToSetParams.getCid()).
				queryParam("pos", RequestStepsToSetParams.getPos()).
				when().
				get("/fees");
		
		CreateCartResponseHolder.setResponse(resp);
		
	}
	
}
