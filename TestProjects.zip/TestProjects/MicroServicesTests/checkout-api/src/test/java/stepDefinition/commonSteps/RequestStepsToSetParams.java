package stepDefinition.commonSteps;

import cucumber.api.java.en.Given;
import masterData.PosMarketMapping;
import requestHolders.CheckoutRequestProperties;

public class RequestStepsToSetParams {

	public static String cid;
	public static String pos;
	
	@Given("^The cid is: ? (.*)$")
	public void setCid(String cid) throws Throwable {
		
		RequestStepsToSetParams.cid = cid;
	}

	@Given("^The pos is: ? (.*)$")
	public void setPos(String pos) throws Throwable {
	   
		RequestStepsToSetParams.pos = pos;
		String market = PosMarketMapping.getMarketFromPos(pos);
		CheckoutRequestProperties.setMarket(market);
	}

	public static String getCid() {
		return cid;
	}

	public static String getPos() {
		return pos;
	}
	
	
}
