package stepDefinition;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import responseHolders.CreateCartResponseHolder;

public class CheckoutResponseValidatorSteps {
	
	@Then("^Response code should be: (\\d+)$")
	@Given("^New cart is created successfully with response code: (\\d+)$")
	public void assertResponseCode(int expectedResponseCode) throws Throwable {
		
		System.out.println("Response code: " + CreateCartResponseHolder.getResponseCode());
		System.out.println("Resposne: " + CreateCartResponseHolder.getResponseBody());
		//log.info("Response code: " + resp.getStatusCode());
		//log.info("Response: " + resp.asString());
		assertEquals(expectedResponseCode, CreateCartResponseHolder.getResponseCode());
	}

	@Then("^Field \"([^\"]*)\" should exist in response$") //@Then("^Field ? (.*) should exist in response$") -> if using value from outline table 
	public void fieldExistsInResponse(String fieldPath) throws Throwable {

		System.out.println("Response." + fieldPath + ": " + CreateCartResponseHolder.response.then().extract().path(fieldPath));
		assertTrue(CreateCartResponseHolder.response.then().extract().path(fieldPath) != null);
	}

	@Then("^Response contains error code: ? (.*)$")
	public void assertErrorCode(String expectedErrorCode) throws Throwable {

		String actualErrorCode = CreateCartResponseHolder.response.then().extract().path("errors[0].code");
		assertTrue(actualErrorCode.equals(expectedErrorCode));

	}

	@Then("^Response contains error message: ? (.*)$")
	public void assertErrorMessage(String expectedErrorMessage) throws Throwable {

		String actualErrorMessage = CreateCartResponseHolder.response.then().extract().path("errors[0].message");
		assertTrue(actualErrorMessage.contains(expectedErrorMessage));
	}
	
	@Then("^Response contains reason: ? (.*)$")
	public void assertErrorReason(String expectedErrorReason) throws Throwable {

		String actualErrorReason = CreateCartResponseHolder.response.then().extract().path("errors[0].reason");
		assertTrue(actualErrorReason.contains(expectedErrorReason));
	}
	
	@Then("^Currency in response should be: ? (.*)$")
	public void assertCurrency(String expectedCurrency) throws Throwable {
	    
		String actualCurrency = CreateCartResponseHolder.response.then().extract().path("currency");
		assertTrue(actualCurrency.contains(expectedCurrency));
	}
	
	
}
