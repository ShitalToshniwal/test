package stepDefinition;

import static com.jayway.restassured.RestAssured.given;

//import java.io.File;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.Response;

import checkoutServiceDomain.CheckoutCart;
import checkoutServiceDomain.ContactDetails;
//import checkoutServiceDomain.ContactDetails;
import checkoutServiceDomain.Passengers;
import checkoutServiceDomain.journeys.Journey;
import checkoutServiceDomain.payments.Payment;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;

import static org.junit.Assert.assertEquals;

import requestHolders.CheckoutRequestProperties;
import requestHolders.SearchRequestProperties;
import stepDefinition.commonSteps.RequestStepsToSetParams;
import library.CheckoutRequestBuilder;
import library.SearchResponseExtractor;
import library.SearchSeats;
import masterData.ClassOfAccom;
import responseHolders.CreateCartResponseHolder;
import responseHolders.SearchResponseHolder;;

public class CheckoutCartSteps {

	public static String jsonRequestsFolder; // = "CheckoutCart";
	private Response resp;
	
	public static CheckoutCart newCheckoutCart = new CheckoutCart();
	public static Payment newPayment = new Payment();
	public static ContactDetails newContactDetails = new ContactDetails();
	public static Passengers newPassengers = new Passengers();
	public static Journey newSelectedOutbound = new Journey();
	public static Journey newSelectedInbound = new Journey();
	
	/*@Given("^I build checkout cart request using \"([^\"]*)\" with value: ? (.*)$")
	public void buildRequest_CheckoutCart(String fieldName, String fieldValue) throws Throwable {
		
		System.out.println("fieldName: " + fieldName);
		System.out.println("fieldValue: " + fieldValue);
		
		String[] arrfieldNames = fieldName.split("\\.");
		for(int i = 0; i < arrfieldNames.length; i++)
		{
			//System.out.println(arrfieldNames[i]);
			switch(arrfieldNames[i])
			{
				case "currency":
					newCheckoutCart.setCurrency(fieldValue);
					break;
				case "totalPrice":
					newCheckoutCart.setTotalPrice(fieldValue);
					break;
				
			}
		}
	    
	    
	}*/
	
	@Given("^The journey is a one way journey with outbound date: ? (.*)$")
	public void setJourneyDates(String outboundDate) throws Throwable {
	    
		//System.out.println(outboundDate);
		SearchRequestProperties.setOutboundDate(outboundDate);
	}

	@Given("^Pax details are: ? (.*) adults, ? (.*) youths, ? (.*) children$")
	public void pax_details_are_numOfAdults_adults_numOfYouths_youths_numOfChildren_children(int numOfAdults, int numOfYouths, int numOfChildren) throws Throwable {
	    
		//System.out.println(numOfAdults + "-" + numOfYouths + "-" + numOfChildren);
		SearchRequestProperties.setNumOfAdults(numOfAdults);
		SearchRequestProperties.setNumOfYouths(numOfYouths);
		SearchRequestProperties.setNumOfChildren(numOfChildren);
	
	}

	@Given("^Origin: (\\d+) and Destination: (\\d+)$")
	public void origin_and_Destination(int originCode, int destinationCode) throws Throwable {
	 
		//System.out.println(origin + "-" + destination);
		SearchRequestProperties.setOrigin(originCode);
		SearchRequestProperties.setDestination(destinationCode);
		newSelectedOutbound.setOriginCode(originCode);
		newSelectedOutbound.setDestinationCode(destinationCode);
	}
	
	@Given("^Class of accomodation is: ? (.*)$")
	public void setClassOfAccom(String classOfAccom) throws Throwable {
	 
		String classOfAccomCode = ClassOfAccom.getClassOfAccomCode(classOfAccom);
		CheckoutRequestProperties.setClassOfAccomCode(classOfAccomCode);
	}
	
	@Given("^\"([^\"]*)\" request returns response code: (\\d+)$")
	public void executeSearchSeats(String requestName, int expectedStatusCode) throws Throwable {
	 
		switch(requestName){
		case "Search Seats":
			SearchSeats.searchSeats();
			assertEquals(expectedStatusCode, SearchResponseHolder.getResponseCode());
			break;
		case "Create Cart":
			CreateCartSteps.executeCreateCart();
			assertEquals(expectedStatusCode, CreateCartResponseHolder.getResponseCode());
			break;
		default:
			break;
		}
		
	}
	
	@Given("^I build checkout request including data extracted from search response$")
	public void buildCheckoutRequest()throws Throwable {
		
		SearchResponseExtractor.extractDataFromSearchResponse();

		CheckoutRequestBuilder
		ObjectMapper objMapperTemp = new ObjectMapper();
		//System.out.println(objMapperTemp.writeValueAsString(CheckoutCartSteps.newCheckoutCart));
	}
	
	@When("^I checkout a new cart$")
	public void executeCheckoutCart() throws Throwable {
		
		ObjectMapper objMapperTemp = new ObjectMapper();
		System.out.println(objMapperTemp.writeValueAsString(CheckoutCartSteps.newCheckoutCart));
		
		System.out.println("cart id: " + CheckoutRequestProperties.getCartId());
		resp = given().log().all().
				header("cid", RequestStepsToSetParams.getCid()).
				queryParam("pos", RequestStepsToSetParams.getPos()).
				pathParam("cartId", CheckoutRequestProperties.getCartId()).
				body(objMapperTemp.writeValueAsString(CheckoutCartSteps.newCheckoutCart)).
				when().
				contentType(ContentType.JSON).
				post("/carts/{cartId}/checkout");
		
		CreateCartResponseHolder.setResponse(resp);
		//System.out.println(resp.asString());
		
	}
	
}