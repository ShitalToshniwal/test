package library;

import static com.jayway.restassured.RestAssured.given;

import com.jayway.restassured.response.Response;

import requestHolders.SearchRequestProperties;
import responseHolders.SearchResponseHolder;
import stepDefinition.commonSteps.RequestStepsToSetParams;

public class SearchSeats {

	public static void searchSeats(){
		
		//execute request for search service
		Response resp = given().//log().all().
				header("cid", RequestStepsToSetParams.getCid()).
				pathParam("pos", RequestStepsToSetParams.getPos()).
				pathParam("origin", SearchRequestProperties.getOrigin()).
				pathParam("destination", SearchRequestProperties.getDestination()).
				queryParam("outbound-date", SearchRequestProperties.getOutboundDate()).
				queryParam("adult", SearchRequestProperties.getNumOfAdults()).
				queryParam("youth", SearchRequestProperties.getNumOfYouths()).
				queryParam("child", SearchRequestProperties.getNumOfChildren()).
				when().
				get(BaseClass.searchServiceURL + "/train-search/{pos}/{origin}/{destination}");
		
		SearchResponseHolder.setResponse(resp);
		//System.out.println(resp.asString());
		
		
	}
	
}
