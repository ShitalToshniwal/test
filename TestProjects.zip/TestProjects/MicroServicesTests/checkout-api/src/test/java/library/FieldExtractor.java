package library;

import responseHolders.CreateCartResponseHolder;

public class FieldExtractor {

	public static String extractValueOfFieldFromResponse(String fieldPath){

		String value = CreateCartResponseHolder.response.then().extract().path(fieldPath);
		return value;
	}
}
