package library;

import org.junit.BeforeClass;

/*import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.core.LoggerContext;
import org.apache.logging.log4j.core.config.*;*/


import com.jayway.restassured.RestAssured;

import stepDefinition.CheckoutCartSteps;
import stepDefinition.CreateCartSteps;

public class BaseClass {

	public static String searchServiceURL;
	public static String datacashURL;
	public static String jsonRequestsFolderPath;
	//public final Logger log = LogManager.getLogger("log4j2");
	
	@BeforeClass
	public static void setup(){
		
		RestAssured.baseURI = "http://checkout-v1-test.trainz.io";
		searchServiceURL = "http://search-v1-test.trainz.io";
		datacashURL = "https://accreditation.datacash.com/hps-cnp_a";
		jsonRequestsFolderPath = System.getProperty("user.dir") + "\\src\\test\\resources\\checkout\\jsonRequests\\";
		
		CreateCartSteps.jsonRequestsFolder = "CreateCart";
		CheckoutCartSteps.jsonRequestsFolder = "CheckoutCart";
	}

}
