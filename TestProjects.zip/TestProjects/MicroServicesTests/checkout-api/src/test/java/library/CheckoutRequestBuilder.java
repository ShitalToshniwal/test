package library;

import requestHolders.CheckoutRequestProperties;
import stepDefinition.CheckoutCartSteps;

public class CheckoutRequestBuilder {
	

	//build rest of the fields under payment block in checkout request
	public static void buildPaymentBlock(){
		
		//fee
		
		//card
		
		//merchantUrl
		
		
		//riskDetails
		
		//CheckoutPaymentDetails paymentDetails = new CheckoutPaymentDetails();
		//CheckoutCartSteps.newCheckoutCart.setPayment(CheckoutPaymentDetails.getCheckoutPaymentDetails());
	}
}
