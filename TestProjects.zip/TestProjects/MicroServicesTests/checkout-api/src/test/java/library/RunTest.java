package library;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		plugin = {"pretty", "html:target/reports/html/"},
		features = "src/test/resources/features",
		glue = {"stepDefinition"},
		tags = {"@CheckoutCart"}
		)
public class RunTest extends BaseClass{

}
