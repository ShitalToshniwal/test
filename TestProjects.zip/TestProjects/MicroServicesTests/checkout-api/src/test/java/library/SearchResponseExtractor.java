package library;

import java.lang.reflect.Array;
import java.util.ArrayList;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import checkoutServiceDomain.Passengers;
import checkoutServiceDomain.journeys.Fares;
import checkoutServiceDomain.journeys.Legs;
import masterData.PassengerNames;
import masterData.PassengerTitles;
import requestHolders.CheckoutRequestProperties;
import responseHolders.SearchResponseHolder;
import stepDefinition.CheckoutCartSteps;

public class SearchResponseExtractor {
	
	public static void extractDataFromSearchResponse() throws Throwable{
		
		String searchResp = SearchResponseHolder.getResponseBody();
		//System.out.println("search resp: " + searchResp);

		//using jackson lib
		ObjectMapper objMapper = new ObjectMapper();
		JsonNode rootNode = objMapper.readTree(searchResp.getBytes());
		//System.out.println("data: " + (rootNode.path("origin")).asText());
		
		//pick currency
		CheckoutCartSteps.newCheckoutCart.setCurrency(rootNode.get("currency").asText());
		
		//pick number of passengers
		CheckoutRequestProperties.setNumOfAdults(Integer.valueOf(rootNode.get("passengerNumber").get("ADULT").asText()));
		CheckoutRequestProperties.setNumOfYouths(Integer.valueOf(rootNode.get("passengerNumber").get("YOUTH").asText()));
		CheckoutRequestProperties.setNumOfChildren(Integer.valueOf(rootNode.get("passengerNumber").get("CHILD").asText()));
		CheckoutRequestProperties.setTotalPassengers();
		
		
		//pick an outbound train with matching class of accommodation code, extract data and put in the relevant object
		boolean trainFound = false;
		JsonNode outboundNode = rootNode.get("outbound");
		int numOfOutboundTrains = outboundNode.size();
		int currentTrainCounter = 0;
		do{
			
			JsonNode chosenOutboundTrain = outboundNode.get(currentTrainCounter);
			//System.out.println(chosenOutboundTrain);
			String outboundDepDate = chosenOutboundTrain.get("route").get("departureDate").asText();
			CheckoutCartSteps.newSelectedOutbound.setDepartureDate(outboundDepDate);
			//System.out.println(outboundDepDate);
			String outboundDepTime = chosenOutboundTrain.get("route").get("departureTime").asText();
			CheckoutCartSteps.newSelectedOutbound.setDepartureTime(outboundDepTime);
			//System.out.println(outboundDepTime);
			String outboundArrDate = chosenOutboundTrain.get("route").get("arrivalDate").asText();
			CheckoutCartSteps.newSelectedOutbound.setArrivalDate(outboundArrDate);
			//System.out.println(outboundArrDate);
			String outboundArrTime = chosenOutboundTrain.get("route").get("arrivalTime").asText();
			CheckoutCartSteps.newSelectedOutbound.setArrivalTime(outboundArrTime);
			//System.out.println(outboundArrTime);
			
			//iterate through each leg
			JsonNode outboundSegments = chosenOutboundTrain.get("segments");
			int numOfoutboundLegs = outboundSegments.size();
			ArrayList<Legs> lstLegObjects = new ArrayList<Legs>();
			Legs tempLegObj = new Legs();
			for(int legCounter = 0; legCounter < numOfoutboundLegs; legCounter++){
				JsonNode leg = outboundSegments.get(legCounter);
				//System.out.println(leg);
				String originLeg = leg.get("route").get("origin").asText();
				tempLegObj.setOriginCode(originLeg);
				//System.out.println(originLeg);
				String destinationLeg = leg.get("route").get("destination").asText();
				tempLegObj.setDestinationCode(destinationLeg);
				//System.out.println(destinationLeg);
				String departureDateLeg = leg.get("route").get("departureDate").asText();
				tempLegObj.setDepartureDate(departureDateLeg);
				//System.out.println(departureDateLeg);
				String departureTimeLeg = leg.get("route").get("departureTime").asText();
				tempLegObj.setDepartureTime(departureTimeLeg);
				//System.out.println(departureTimeLeg);
				String arrivalDateLeg = leg.get("route").get("arrivalDate").asText();
				tempLegObj.setArrivalDate(arrivalDateLeg);
				//System.out.println(arrivalDateLeg);
				String arrivalTimeLeg = leg.get("route").get("arrivalTime").asText();
				tempLegObj.setArrivalTime(arrivalTimeLeg);
				//System.out.println(arrivalTimeLeg);
				String equipmentTypeLeg = leg.get("equipmentType").asText();
				tempLegObj.setEquipmentType(equipmentTypeLeg);
				//System.out.println(equipmentTypeLeg);
				String trainNumberLeg = leg.get("trainNumber").asText();
				tempLegObj.setTrainNumber(trainNumberLeg);
				//System.out.println(trainNumberLeg);
				String carrierLeg = leg.get("carrier").asText();
				tempLegObj.setCarrierCode(carrierLeg);
				//System.out.println(carrierLeg);
				lstLegObjects.add(tempLegObj);
			}
			
			//iterate through fare codes
			JsonNode outboundPrices = chosenOutboundTrain.get("prices");
			//System.out.println(outboundPrices);
			int numOfAccomClasses = outboundPrices.size();
			for(int accomClassCounter = 0; accomClassCounter < numOfAccomClasses; accomClassCounter++){
				JsonNode accomClassDetails = outboundPrices.get(accomClassCounter);
				//System.out.println("accomClassDetails" + accomClassDetails);
				//System.out.println(accomClassDetails.get("accomClass").asText());
				if(accomClassDetails.get("accomClass").asText().equals(CheckoutRequestProperties.getClassOfAccomCode()) && accomClassDetails.get("totalRemainingSeats").asInt() > 0)
				{
					Boolean passengerBlockCaptured = false;
					//pick totalPrice
					CheckoutCartSteps.newCheckoutCart.setTotalPrice(accomClassDetails.get("totalPrice").asText());
					
					ArrayList<Fares> faresLeg = new ArrayList<Fares>();
					
					//System.out.println(accomClassDetails.get("totalPrice").asText());
					JsonNode segmentPriceList = accomClassDetails.get("segmentPriceList");
					for(int legCounterPriceNode = 0; legCounterPriceNode < numOfoutboundLegs; legCounterPriceNode++){
						JsonNode faresLegPriceNode = segmentPriceList.get(legCounterPriceNode).get("fares");
						System.out.println("fares: " + faresLegPriceNode.size());
						
						if(!passengerBlockCaptured){
							
							ArrayList<Passengers> lstPassengers = new ArrayList<Passengers>();
						
							for(int paxCounter = 0; paxCounter < faresLegPriceNode.size(); paxCounter++){
								System.out.println("paxCounter = " + paxCounter);
															
								JsonNode faresNode = faresLegPriceNode.get(paxCounter);
				
								Passengers passengerObject = new Passengers();
								passengerObject.setId(faresNode.get("passengerId").asText());
								passengerObject.setTitle(PassengerTitles.getPassengerTitle());
								passengerObject.setFirstName(PassengerNames.getFirstName(paxCounter));
								passengerObject.setLastName(PassengerNames.getLastName(paxCounter));
								passengerObject.setType(faresNode.get("passengerType").asText());
								int age = 60;
								switch(faresNode.get("passengerType").asText())
		            			{
		            				case "ADULT":
		            					age = 30;
		            					break;
		            				case "YOUTH":
		            					age = 15;
		            					break;
		            				case "CHILD":
		            					age = 5;
		            					break;
		            				default:
		            					break;
		            			}
								passengerObject.setAge(age);
								lstPassengers.add(paxCounter, passengerObject);
								
								
							}
							passengerBlockCaptured = true;
							CheckoutCartSteps.newCheckoutCart.setPassengers(lstPassengers);
						}
						
						for(int paxCounter = 0; paxCounter < faresLegPriceNode.size(); paxCounter++){
							
							Fares tempFaresObj = new Fares();
							JsonNode faresNode = faresLegPriceNode.get(paxCounter);
							
							ArrayList<String> paxId = new ArrayList<String>();
							String passId = faresNode.get("passengerId").asText();
							paxId.add(0, passId);
							tempFaresObj.setPassengerIds(paxId);
							String paxType = faresNode.get("passengerTypeCode").asText();
							tempFaresObj.setPassengerTypeCode(paxType);
							String paxClassOfService = faresNode.get("classOfService").asText();
							tempFaresObj.setClassOfService(paxClassOfService);
							String paxFareCode = faresNode.get("fareCode").asText();
							tempFaresObj.setFareCode(paxFareCode);
							faresLeg.add(paxCounter, tempFaresObj);
							
							
							
							/*faresLeg.setPassengerIds(paxCounter);
							String paxType = faresNode.get("paxType").asText();
							faresLeg.setPassengerTypeCode(paxCounter, paxType);
							//System.out.println(paxType);
							String paxClassOfService = faresNode.get("classOfService").asText();
							faresLeg.setClassOfService(paxCounter, paxClassOfService);
							//System.out.println(paxClassOfService);
							String paxFareCode = faresNode.get("fareCode").asText();
							faresLeg.setFareCode(paxCounter, paxFareCode);
							//System.out.println(paxFareCode);*/
							
							
							
						}
						tempLegObj.setFares(faresLeg);
					}
					
					CheckoutCartSteps.newSelectedOutbound.setLegs(lstLegObjects);
					//ObjectMapper objMapperTemp = new ObjectMapper();
					//System.out.println(objMapperTemp.writeValueAsString(CheckoutCartSteps.newSelectedOutbound));
					trainFound = true;
					break;
				}
			}
		}
		while (trainFound == false || currentTrainCounter >= numOfOutboundTrains);
		
		
		CheckoutCartSteps.newCheckoutCart.setSelectedOutbound(CheckoutCartSteps.newSelectedOutbound);		
		System.out.println(objMapper.writeValueAsString(CheckoutCartSteps.newSelectedOutbound));
		/*Iterator<JsonNode> elements = outboundNode.elements();
		while(elements.hasNext()){
			System.out.println(elements.next());
		}*/
		
		/*using simple json
		 * JSONParser parser = new JSONParser();
		JSONObject json = (JSONObject) parser.parse(searchResp);
		//System.out.println("outbound: " + json.get("outbound"));
			
		//JSONArray arr = (JSONArray) json.get("outbound");
		print each train in outbound section
		 for(int i = 0; i < arr.size(); i++)
			System.out.println("array: " + arr.get(i));

		//get the first outbound train
		//JSONObject chosenOutboundTrain = arr.get(0);
		//System.out.println("first outbound train: " + chosenOutboundTrain.get("route");
		*/
		
	}
}
