package checkoutServiceDomain.journeys;

import java.util.ArrayList;

public class Journey {

	private int originCode;
    private String departureDate;
    private String departureTime;
    private int destinationCode;
    private String arrivalDate;
    private String arrivalTime;
    private ArrayList<Legs> legs;
    
	public int getOriginCode() {
		return originCode;
	}
	
	public void setOriginCode(int originCode) {
		this.originCode = originCode;
	}
	
	public String getDepartureDate() {
		return departureDate;
	}
	
	public void setDepartureDate(String departureDate) {
		this.departureDate = departureDate;
	}
	
	public String getDepartureTime() {
		return departureTime;
	}
	
	public void setDepartureTime(String departureTime) {
		this.departureTime = departureTime;
	}
	
	public int getDestinationCode() {
		return destinationCode;
	}
	
	public void setDestinationCode(int destinationCode) {
		this.destinationCode = destinationCode;
	}
	
	public String getArrivalDate() {
		return arrivalDate;
	}
	
	public void setArrivalDate(String arrivalDate) {
		this.arrivalDate = arrivalDate;
	}
	
	public String getArrivalTime() {
		return arrivalTime;
	}
	
	public void setArrivalTime(String arrivalTime) {
		this.arrivalTime = arrivalTime;
	}
	
	public ArrayList<Legs> getLegs() {
		return legs;
	}
	
	public void setLegs(ArrayList<Legs> lstLegObjects) {
		this.legs = lstLegObjects;
	}
   
    
    
}
