package checkoutServiceDomain.journeys;

import java.util.ArrayList;

public class Legs {

	private String originCode;
	private String departureDate;
	private String departureTime;
	private String destinationCode;
	private String arrivalDate;
	private String arrivalTime;
	private String trainNumber;
	private String equipmentType;
	private String carrierCode;
	private ArrayList<Fares> fares = new ArrayList<Fares>();
	
	public String getOriginCode() {
		return originCode;
	}
	
	public void setOriginCode(String originCode) {
		this.originCode = originCode;
	}
	
	public String getDepartureDate() {
		return departureDate;
	}
	
	public void setDepartureDate(String departureDate) {
		this.departureDate = departureDate;
	}
	
	public String getDepartureTime() {
		return departureTime;
	}
	
	public void setDepartureTime(String departureTime) {
		this.departureTime = departureTime;
	}
	
	public String getDestinationCode() {
		return destinationCode;
	}
	
	public void setDestinationCode(String destinationCode) {
		this.destinationCode = destinationCode;
	}
	
	public String getArrivalDate() {
		return arrivalDate;
	}
	
	public void setArrivalDate(String arrivalDate) {
		this.arrivalDate = arrivalDate;
	}
	
	public String getArrivalTime() {
		return arrivalTime;
	}
	
	public void setArrivalTime(String arrivalTime) {
		this.arrivalTime = arrivalTime;
	}
	
	public String getTrainNumber() {
		return trainNumber;
	}
	
	public void setTrainNumber(String trainNumber) {
		this.trainNumber = trainNumber;
	}
	
	public String getEquipmentType() {
		return equipmentType;
	}
	
	public void setEquipmentType(String equipmentType) {
		this.equipmentType = equipmentType;
	}
	
	public String getCarrierCode() {
		return carrierCode;
	}
	
	public void setCarrierCode(String carrierCode) {
		this.carrierCode = carrierCode;
	}
	
	public ArrayList<Fares> getFares() {
		return fares;
	}
	
	public void setFares(ArrayList<Fares> faresLeg) {
		this.fares = faresLeg;
	}

	
}
