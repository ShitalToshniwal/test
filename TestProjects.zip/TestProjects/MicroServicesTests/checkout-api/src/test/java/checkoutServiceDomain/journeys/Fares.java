package checkoutServiceDomain.journeys;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class Fares {
	
	private ArrayList<String> passengerIds;
	private String classOfService;
	private String fareCode;
	private String passengerTypeCode;
	
	public ArrayList<String> getPassengerIds() {
		return passengerIds;
	}
	
	public void setPassengerIds(ArrayList<String> arrTempPaxId) {
		this.passengerIds = arrTempPaxId;
	}
	
	public String getClassOfService() {
		return classOfService;
	}
	
	public void setClassOfService(String classOfService) {
		this.classOfService = classOfService;
	}
	
	public String getFareCode() {
		return fareCode;
	}
	
	public void setFareCode(String fareCode) {
		this.fareCode = fareCode;
	}
	
	public String getPassengerTypeCode() {
		return passengerTypeCode;
	}
	
	public void setPassengerTypeCode(String passengerTypeCode) {
		this.passengerTypeCode = passengerTypeCode;
	}
	

	/*
	private ArrayList<String> arrpassengerId = new ArrayList<String>();
    private ArrayList<String> arrclassOfService = new ArrayList<String>();
    private ArrayList<String> arrfareCode = new ArrayList<String>();
    private ArrayList<String> arrpassengerTypeCode = new ArrayList<String>();
    
	public ArrayList<String> getPassengerIds() {
		return arrpassengerId;
	}
	
	public void setPassengerIds(int paxIndex) {
		this.arrpassengerId.add(String.valueOf(paxIndex));
		//this.passengerId = passengerId;
	}
	
	public ArrayList<String> getClassOfService() {
		return arrclassOfService;
	}
	
	public void setClassOfService(int paxIndex, String classOfService) {
		this.arrclassOfService.add(paxIndex, classOfService);
		//this.classOfService = classOfService;
	}
	
	public ArrayList<String> getFareCode() {
		return arrfareCode;
	}
	
	public void setFareCode(int paxIndex, String fareCode) {
		this.arrfareCode.add(paxIndex, fareCode);
		//this.fareCode = fareCode;
	}
	
	public ArrayList<String> getPassengerTypeCode() {
		return arrpassengerTypeCode;
	}
	
	public void setPassengerTypeCode(int paxIndex, String passengerTypeCode) {
		this.arrpassengerTypeCode.add(paxIndex, passengerTypeCode);
		//this.passengerTypeCode = passengerTypeCode;
	}
       */
    
}
