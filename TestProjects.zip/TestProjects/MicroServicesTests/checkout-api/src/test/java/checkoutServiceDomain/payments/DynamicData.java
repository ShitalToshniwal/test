package checkoutServiceDomain.payments;

public class DynamicData {

	private String dynData1;
	private String dynData2;
	private String dynData3;
	private String dynData4;
	private String dynData5;
	private String dynData6;
	private String dynData7;
	private String dynData8;
	private String dynData9;
	
	public String getDynData1() {
		return dynData1;
	}
	
	public void setDynData1(String dynData1) {
		this.dynData1 = dynData1;
	}
	
	public String getDynData2() {
		return dynData2;
	}
	
	public void setDynData2(String dynData2) {
		this.dynData2 = dynData2;
	}
	
	public String getDynData3() {
		return dynData3;
	}
	
	public void setDynData3(String dynData3) {
		this.dynData3 = dynData3;
	}
	
	public String getDynData4() {
		return dynData4;
	}
	
	public void setDynData4(String dynData4) {
		this.dynData4 = dynData4;
	}
	
	public String getDynData5() {
		return dynData5;
	}
	
	public void setDynData5(String dynData5) {
		this.dynData5 = dynData5;
	}
	
	public String getDynData6() {
		return dynData6;
	}
	
	public void setDynData6(String dynData6) {
		this.dynData6 = dynData6;
	}
	
	public String getDynData7() {
		return dynData7;
	}
	
	public void setDynData7(String dynData7) {
		this.dynData7 = dynData7;
	}
	
	public String getDynData8() {
		return dynData8;
	}
	
	public void setDynData8(String dynData8) {
		this.dynData8 = dynData8;
	}
	
	public String getDynData9() {
		return dynData9;
	}
	
	public void setDynData9(String dynData9) {
		this.dynData9 = dynData9;
	}
	
	
}