package checkoutServiceDomain;

import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonInclude;

import checkoutServiceDomain.journeys.Journey;
import checkoutServiceDomain.payments.Payment;


public class CheckoutCart {

	private String currency;
	private String totalPrice;
	private Payment payment;
	private ContactDetails contactDetails;
	private ArrayList<Passengers> passengers;
	private Journey selectedOutbound;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Journey selectedInbound;
	
	public String getCurrency() {
		return currency;
	}
	
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	
	public String getTotalPrice() {
		return totalPrice;
	}
	
	public void setTotalPrice(String totalPrice) {
		this.totalPrice = totalPrice;
	}
	
	public Payment getPayment() {
		return payment;
	}
	
	public void setPayment(Payment payment) {
		this.payment = payment;
	}
	
	public ContactDetails getContactDetails() {
		return contactDetails;
	}
	
	public void setContactDetails(ContactDetails contactDetails) {
		this.contactDetails = contactDetails;
	}
	
	public ArrayList<Passengers> getPassengers() {
		return passengers;
	}
	
	public void setPassengers(ArrayList<Passengers> lstPassengers) {
		this.passengers = lstPassengers;
	}
	
	public Journey getSelectedOutbound() {
		return selectedOutbound;
	}
	
	public void setSelectedOutbound(Journey selectedOutbound) {
		this.selectedOutbound = selectedOutbound;
	}
	
	public Journey getSelectedInbound() {
		return selectedInbound;
	}
	
	public void setSelectedInbound(Journey selectedInbound) {
		this.selectedInbound = selectedInbound;
	}
	
	
}
