package checkoutServiceDomain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;


public class Amount {

	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String currency;
	@JsonInclude(JsonInclude.Include.NON_DEFAULT)
	private double value;
	
	public String getCurrency() {
		return currency;
	}
	
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	
	public double getValue() {
		return value;
	}
	
	public void setValue(double value) {
		this.value = value;
	}
	
	
}
