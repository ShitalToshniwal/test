package checkoutServiceDomain.payments;

import com.fasterxml.jackson.annotation.JsonInclude;

public class PaymentSetup {

	private String pageSetId;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String returnUrl;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String expiryUrl;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private DynamicData dynamicData;
	
	public String getPageSetId() {
		return pageSetId;
	}
	
	public void setPageSetId(String pageSetId) {
		this.pageSetId = pageSetId;
	}
	
	public String getReturnUrl() {
		return returnUrl;
	}
	
	public void setReturnUrl(String returnUrl) {
		this.returnUrl = returnUrl;
	}
	
	public String getExpiryUrl() {
		return expiryUrl;
	}
	
	public void setExpiryUrl(String expiryUrl) {
		this.expiryUrl = expiryUrl;
	}
	
	public DynamicData getDynamicData() {
		return dynamicData;
	}
	
	public void setDynamicData(DynamicData dynamicData) {
		this.dynamicData = dynamicData;
	}
	
	
}
