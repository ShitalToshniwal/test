package checkoutServiceDomain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
//import javax.xml.bind.annotation.XmlRootElement;

import checkoutServiceDomain.payments.PaymentSetup;

//@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
//@JsonIgnoreProperties(value = { "Amount" })
//@XmlRootElement
public class NewCart {

	//@JsonInclude(JsonInclude.Include.NON_DEFAULT)
	@JsonIgnore
	private Amount amount;
	private PaymentSetup paymentSetup;
	
	public Amount getAmount() {
		return amount;
	}
	
	public void setAmount(Amount amount) {
		this.amount = amount;
	}
	
	public PaymentSetup getPaymentSetup() {
		return paymentSetup;
	}
	
	public void setPaymentSetup(PaymentSetup paymentSetup) {
		this.paymentSetup = paymentSetup;
	}
	
	
}
