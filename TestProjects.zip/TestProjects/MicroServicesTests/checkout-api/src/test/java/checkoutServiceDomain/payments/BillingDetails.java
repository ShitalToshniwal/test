package checkoutServiceDomain.payments;

public class BillingDetails {

	private String name;
	private BillingAddress billingAddress;
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public BillingAddress getBillingAddress() {
		return billingAddress;
	}
	
	public void setBillingAddress(BillingAddress billingAddress) {
		this.billingAddress = billingAddress;
	}
	
	
}
