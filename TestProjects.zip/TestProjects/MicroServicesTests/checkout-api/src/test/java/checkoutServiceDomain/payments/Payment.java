package checkoutServiceDomain.payments;

public class Payment {

	private BillingDetails billingDetails;
	private String fee;
	private Card card;
	private String merchantUrl;
	private RiskDetails riskDetails;
	
	public BillingDetails getBillingDetails() {
		return billingDetails;
	}
	
	public void setBillingDetails(BillingDetails billingDetails) {
		this.billingDetails = billingDetails;
	}
	
	public String getFee() {
		return fee;
	}
	
	public void setFee(String fee) {
		this.fee = fee;
	}
	
	public Card getCard() {
		return card;
	}
	
	public void setCard(Card card) {
		this.card = card;
	}
	
	public String getMerchantUrl() {
		return merchantUrl;
	}
	
	public void setMerchantUrl(String merchantUrl) {
		this.merchantUrl = merchantUrl;
	}
	
	public RiskDetails getRiskDetails() {
		return riskDetails;
	}
	
	public void setRiskDetails(RiskDetails riskDetails) {
		this.riskDetails = riskDetails;
	}
	
	
}
  