package checkoutServiceDomain.payments;

public class RiskDetails {

    private String browserLanguage;
    private String ipAddress;
    private String userMachineId;
    private String sessionId;
    
	public String getBrowserLanguage() {
		return browserLanguage;
	}
	
	public void setBrowserLanguage(String browserLanguage) {
		this.browserLanguage = browserLanguage;
	}
	
	public String getIpAddress() {
		return ipAddress;
	}
	
	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}
	
	public String getUserMachineId() {
		return userMachineId;
	}
	
	public void setUserMachineId(String userMachineId) {
		this.userMachineId = userMachineId;
	}
	
	public String getSessionId() {
		return sessionId;
	}
	
	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

}
