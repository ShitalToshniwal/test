package countryTests;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.Assert;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.*;
import static com.jayway.restassured.RestAssured.*;

import testFramework.TCExecutor;


public class CountryTests {

	public static String varApiURL = "";

	@BeforeTest
	public static void getEnvironment() throws Exception{

		Properties prop = new Properties();
		InputStream input = null;

		try {

			input = new FileInputStream(TCExecutor.TESTCASE_FILE_PATH + "\\src\\test\\java\\testData\\" + TCExecutor.PROPERTIES_FILE_NAME );
			prop.load(input);
			String propRead[]=(prop.getProperty("website").split(","));
			varApiURL = propRead[0].toString();
			//System.out.println(varApiURL);

		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}

	@Test
	public static void getAllCountries() throws Exception{

		try{
			
			Response resp = when().
							get(varApiURL + "/country/get/all");
			
			System.out.println(resp.asString());
			Assert.assertEquals(resp.getStatusCode(), 200);

			// To Do: assert on response.. compare with "expected" json
			
			//update csv
			//log using a class method
		}
		catch(Exception e){
			throw(e);
		}
	}

	@Test
	public static void getCountryByIso2Code(String countryCode) throws Exception{
		String tcStatus = "";
		try{
			
			Response resp = given().
							pathParam("alpha2_code", countryCode).
							when(). 
							get(varApiURL + "/country/get/iso2code/{alpha2_code}");

			System.out.println(resp.asString());
			//Assert.assertEquals(resp.getStatusCode(), 200);
			switch(resp.getStatusCode()){
				case 200:
					Assert.assertTrue(true);
					TCExecutor.testCaseStatus = "Passed";
					break;
				default:
					Assert.assertFalse(true);
					TCExecutor.testCaseStatus = "Failed";
			}
		
			
			//update csv
			//log using a class method
		}
		catch(Exception e){
			throw(e);
		}

	}

	@Test
	public static void getCountryByIso3Code(String countryCode) throws Exception{

		try{	
			
			Response resp = given().
							pathParam("alpha3_code", countryCode).
							when(). 
							get(varApiURL + "/country/get/iso3code/{alpha3_code}");

			System.out.println(resp.asString());
			Assert.assertEquals(resp.getStatusCode(), 200);
			
			//update csv
			//log using a class method
		}
		catch(Exception e){
			throw(e);
		}

	}

	@Test
	public static void getCountryBySearch(String searchText) throws Exception{

		try{
			Response resp = given().
					param("text", searchText).
					when(). 
					get(varApiURL + "/country/search");

			System.out.println(resp.asString());
			Assert.assertEquals(resp.getStatusCode(), 200);
			
			//update csv
			//log using a class method
		}
		catch(Exception e){
			throw(e);
		}

	}
}
