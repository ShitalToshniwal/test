package testFramework;

import au.com.bytecode.opencsv.*;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import countryTests.CountryTests;

public class TCExecutor {

	public static final String TESTCASE_FILE_PATH = System.getProperty("user.dir");
	public static final String TESTCASE_FILE_NAME = "TestCases.csv";
	public static final String PROPERTIES_FILE_NAME = "Environment.properties";
	
	
	public static String testCaseStatus;

	public static void main(String[] args) throws Exception {

		CountryTests.getEnvironment();
		
		CSVReader reader = null;
		
		CSVWriter writer = new CSVWriter(new FileWriter(TESTCASE_FILE_PATH + "\\test-output\\TestRuns\\TestRun1.csv"), CSVWriter.NO_QUOTE_CHARACTER);
		//FileWriter writer = new FileWriter(TESTCASE_FILE_PATH + "\\test-output\\TestRuns\\TestRun1.csv");
		String testCaseStatus = "";
		
		try {
			//open csv file
			//iterate through each test case
			//execute corresponding method for each test case
			//update result in csv
			//export log (assertions and results

			reader = new CSVReader(new FileReader( TESTCASE_FILE_PATH + "\\src\\test\\java\\testData\\" + TESTCASE_FILE_NAME));
			String[] testCase;
			String[] firstLine = reader.readNext();
			String line = "";
			
			for(int i=0; i< firstLine.length; i++){
				line = line + firstLine[i] + ",";	
				
			}
			
		
			line =line.substring(0, line.length() - 1);
			String[] str = {"ABC", "DEF", "GHI", "JKL"};
			writer.writeNext(str);
			
			 
			while ((testCase = reader.readNext()) != null) {
				System.out.println(testCase[0]);
				String testCaseNo = testCase[0];
				String testCaseFunction = testCase[1];
				String testCaseParamValue = testCase[2];
				testCaseStatus = "";

				System.out.println(testCaseFunction);
				switch(testCaseFunction){

				case "all":
					CountryTests.getAllCountries();
					System.out.println(testCase[0] + "," + testCase[1] + "," + testCase[2] + "," + testCaseStatus);
				    line = testCase[0] + "," + testCase[1] + "," + testCase[2] + "," + testCaseStatus;
				    //writer.write(arg0);
				     
					break;
				case "iso2code":
					CountryTests.getCountryByIso2Code(testCaseParamValue);
					break;
				case "iso3code":
					CountryTests.getCountryByIso3Code(testCaseParamValue);
					break;
				case "search":
					CountryTests.getCountryBySearch(testCaseParamValue);
					break;
				default:
					System.out.println("Please enter correct \"Function\" name in input test cases. Expected functions: all, iso2code, iso3code, search");

				}

			}
			writer.close();
		}
		catch (IOException e) {
			e.printStackTrace();
		}

	}

}
