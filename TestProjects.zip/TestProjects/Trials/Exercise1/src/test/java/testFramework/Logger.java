package testFramework;

public class Logger {

	public static void createLogFile() throws Exception{
		
	}
	
	public static void logDetails() throws Exception{
		
	}
	
	public static void closeLogFile() throws Exception{
		
	}
}
