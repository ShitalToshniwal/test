package automationFramework;

import apiTests.CountryTests;
import utility.Constant;
import utility.ExcelUtils;

public class ExcelTC {

	public static void main(String[] args) throws Exception{
		
		try{
			//open excel file
			String path = Constant.TESTDATA_FILE_PATH + "\\src\\test\\java\\testData\\" + Constant.TESTDATA_FILE_NAME;
			System.out.println(path);
			ExcelUtils.setExcelFile(path, "TestCases");
			
			CountryTests.Test_01(0);
		}
		catch(Exception e)
		{
			throw (e);
		}
	}
}