package utility;


public class Constant {
	
	public static final String API_URL = "http://services.groupkt.com";//ExcelUtils.getCellData(0, 1);
	public static final String TESTDATA_FILE_PATH = System.getProperty("user.dir");
	public static final String TESTDATA_FILE_NAME = "TestCases.xlsx";
	
}
