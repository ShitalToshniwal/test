package apiTests;

import utility.Constant;
import utility.ExcelUtils;

public class CountryTests {
	
	public static String apiURL;

	public static void Test_01(int testCaseRow) throws Exception{
		System.out.println("TestCaseRow: " + testCaseRow);
		System.out.println(Constant.API_URL + "//");

		System.out.println("\n\nTrying to read data from " + ExcelUtils.getPath() +
				"\n\n");
		System.out.println(ExcelUtils.getCellData(2, 0));
		System.out.println(ExcelUtils.getCellData(2, 1));
		System.out.println(ExcelUtils.getCellData(2, 2));
		System.out.println(ExcelUtils.getCellData(2, 3));
		System.out.println(ExcelUtils.getCellData(2, 4));

		// Read first row, first col. Should print 'URL'
		System.out.println(ExcelUtils.getCellData(0, 0));

		//Response resp = when().
		//	get(Constant.API_URL);
		//Assert.assertEquals(resp.getStatusCode(), 200);
		//System.out.println(resp.asString());
						
	}
}
