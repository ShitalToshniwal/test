package apiTests;

import org.testng.Assert;
import org.testng.annotations.Test;

import static com.jayway.restassured.RestAssured.*;
import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.*;


public class WeatherGetRequests {

	//simple get request - 200 status code (when)
	//assert only status code
	//@Test
	public void Test_01(){

		Response resp = when().
				get("http://api.openweathermap.org/data/2.5/weather?q=London&appid=45e279cfe4d7e10c9691baf67ce72533");
		Assert.assertEquals(resp.getStatusCode(), 200);
	}

	//simple get request - 401 status code (when)
	//assert only status code
	//@Test
	public void Test_02(){

		Response resp = when().
				get("http://api.openweathermap.org/data/2.5/weather?q=London&appid=45e279");
		Assert.assertEquals(resp.getStatusCode(), 401);
	}

	//get request with parameterisation (given, when)
	//assert only status code
	//@Test
	public void Test_03(){

		Response resp = given().
				param("q", "London").
				param("appid", "45e279cfe4d7e10c9691baf67ce72533").				
				when().
				get("http://api.openweathermap.org/data/2.5/weather");
		Assert.assertEquals(resp.getStatusCode(), 200);
		if(resp.getStatusCode() == 200){
			System.out.println("Param test ok");
		}
		else
		{
			System.out.println("Param test is not ok");
		}
	}

	//get request with parameterisation and assertion is inline in statement (given, when, then)
	//assert only status code
	//@Test
	/*public void Test_04(){

		given().
		param("q", "London").
		param("appid", "45e279cfe4d7e10c9691baf67ce72533").				
		when().
		get("http://api.openweathermap.org/data/2.5/weather").
		then().
		assertThat().statusCode(200);

	}*/

	//get request with parameterisation (given, when)
	//get response body
	//@Test
	public void Test_05(){

		Response resp = given().
						param("id", "2172797").
						param("appid", "45e279cfe4d7e10c9691baf67ce72533").				
						when().
						get("http://api.openweathermap.org/data/2.5/weather");
		
		System.out.println(resp.asString());
		Assert.assertEquals(resp.getStatusCode(), 200);


	}
	
	//get request with parameterisation (given, when, then)
	//extract data from json path in response 
	@Test
	public void Test_06(){
		
		String weatherDescription = given().
									param("id", "2172797").
									param("appid", "45e279cfe4d7e10c9691baf67ce72533").				
									when().
									get("http://api.openweathermap.org/data/2.5/weather").
									then().
									contentType(ContentType.JSON).
									extract().
									path("weather[0].description");
			
		System.out.println("Weather description: " + weatherDescription);


	}
	
	//get request with parameterisation (given, when)
	//extract data from json path from response (using then separately)
	//@Test
	public void Test_07(){

		Response resp = given().
						param("id", "2172797").
						param("appid", "45e279cfe4d7e10c9691baf67ce72533").				
						when().
						get("http://api.openweathermap.org/data/2.5/weather");
		
		String weatherDescription = resp.
									then().
									contentType(ContentType.JSON).
									extract().
									path("weather[0].description");
		
		String expectedDescription = "Clear Skys";
		
		if(weatherDescription.equalsIgnoreCase(expectedDescription)){
			System.out.println("TC passed");
		}
		else{
			System.out.println("TC failed");
			Assert.assertFalse(false);
		}	

	}
	
	//get request with parameterisation (given, when, then)
	//extract longitude and latitude from response and use it in request to another get request
	//@Test
	public void Test_08(){
		
		Response resp = given().
						param("id", "2172797").
						param("appid", "45e279cfe4d7e10c9691baf67ce72533").
						when().
						get("http://api.openweathermap.org/data/2.5/weather");
		String descriptionById = resp.
								then().
								contentType(ContentType.JSON).
								extract().
								path("weather[0].description");
		String longitude = String.valueOf(resp.
											then().
											contentType(ContentType.JSON).
											extract().
											path("coord.lon"));
		String latitude = String.valueOf(resp.
											then().
											contentType(ContentType.JSON).
											extract().
											path("coord.lat"));
		System.out.println(descriptionById);
		System.out.println(longitude);
		System.out.println(latitude);
		
		String descriptionbyCoords = given().
									param("lon", longitude).
									param("lat", latitude).
									param("appid", "45e279cfe4d7e10c9691baf67ce72533").
									when().
									get("http://api.openweathermap.org/data/2.5/weather").
									then().
									contentType(ContentType.JSON).
									extract().
									path("weather[0].description");
		
		System.out.println(descriptionbyCoords);
		Assert.assertEquals(descriptionById, descriptionbyCoords);
	}

}
