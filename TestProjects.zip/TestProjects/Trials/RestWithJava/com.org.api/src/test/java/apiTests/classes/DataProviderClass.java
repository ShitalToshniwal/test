package apiTests.classes;

import org.testng.annotations.DataProvider;

public class DataProviderClass {

	@DataProvider
	public static Object[][] LogInCreds(){
		
		
		Object[][] cred = new Object[4][2];
		cred[0][0] = "User1";
		cred[0][1] = "Pwd1";
		
		cred[1][0] = "User2";
		cred[1][1] = "Pwd2";
		
		cred[2][0] = "User3";
		cred[2][1] = "Pwd3";
		
		cred[3][0] = "User4";
		cred[3][1] = "Pwd4";
		
		
		return cred;
		
	}
	
}
