package apiTests;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import apiTests.classes.DataProviderClass;


public class DataDrivenTests {

	
	//@Test(dataProvider = "LogInCreds", dataProviderClass = DataProviderClass.class)
	public void Test_01(String userId, String password){

		System.out.println("userId: " + userId + ". Password: " + password);
	}
	
	@Test
	@Parameters({"parameter1", "value1"})
	public void Test_02(String parameter1, String value1){

		System.out.println("Parameter1: " + parameter1 + ". Value1: " + value1);
	}
	
	//@Test
	public void Test_03(){
		
		
	}
}
