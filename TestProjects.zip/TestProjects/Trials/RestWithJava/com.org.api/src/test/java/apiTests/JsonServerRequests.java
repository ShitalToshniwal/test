package apiTests;

import org.testng.annotations.Test;

import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.*;

import apiTests.classes.Info;
import apiTests.classes.InfoAdvanced;
import apiTests.classes.Posts;
import apiTests.classes.PostsAdvanced;
import apiTests.classes.PostsInfo;

import static com.jayway.restassured.RestAssured.*;

public class JsonServerRequests {

	//get request
	@Test
	public void Test_01(){
		Response resp = given().
						when().
						get("http://localhost:3000/posts");
		System.out.println("Response is: " + resp.asString());
		System.out.println("Time taken: " + resp.getTime()); //get response time for this call
		System.out.println("Time: " + resp.then().extract().time()); // another way to extract time from resposne
		
	}

	//simple post request - without object
	//@Test
	public void Test_02(){
		Response resp = given().
						body("{\"id\": 2,"
							  + "\"title\": \"dummtTitle\","
							  + "\"author\": \"Tester\"}").
						when().
						contentType(ContentType.JSON).
						post("http://localhost:3000/posts");
		System.out.println("Response is: " + resp.asString());
	}
	
	//post request, using body as object
	//@Test
	public void Test_03(){
		
		Posts post1 = new Posts();
		post1.setId("3");
		post1.setTitle("PostByObj");
		post1.setAuthor("IntTester");
		
		Response resp = given().
						body(post1).
						when().
						contentType(ContentType.JSON).
						post("http://localhost:3000/posts");
		
		System.out.println("Resp through post OBJECT: " + resp.asString());
	}
	
	//get a specific post
	//@Test
	public void Test_04(){
		
		Response resp = given().
						when().
						get("http://localhost:3000/posts/3");
		System.out.println("response: " + resp.asString());
	}
	
	//put request: update a specific post
	//@Test
	public void Test_05(){
		
		Posts post2 = new Posts();
		post2.setId("3");
		post2.setTitle("edited title");
		post2.setAuthor("edited by put request");
		
		Response resp = given().
						body(post2).
						when().
						contentType(ContentType.JSON).
						put("http://localhost:3000/posts/" + post2.getId());
		
		System.out.println("Put response: " + resp.asString());
	}
	
	//patch request: update a specific field for a specific post
	//@Test
	public void Test_06(){
		
		Response resp = given().
						body("{ \"title\": \"edited by patch request\" } ").
						when().
						contentType(ContentType.JSON).
						patch("http://localhost:3000/posts/3");
		System.out.println("Patch response: " + resp.asString());
	}
	
	//delete request
	//@Test
	public void Test_07(){
		
		Response resp = given().
						when().
						delete("http://localhost:3000/posts/2");
		System.out.println("Delete response: " + resp.asString());
		
		Test_01();
		
	}
	
	//complex objects test
	//@Test
	public void Test_08(){
		
		Info info1 = new Info();
		info1.setEmail("test@test.com");
		info1.setPhone("1234567890");
		info1.setAddress("UK");
		
		PostsInfo post1 = new PostsInfo();
		post1.setId("11");
		post1.setTitle("title1");
		post1.setAuthor("author1");
		post1.setInfo(info1);
		
		Response resp = given().
						when().
						contentType(ContentType.JSON).
						body(post1).
						post("http://localhost:3000/posts");
		System.out.println("Complex obj try: " + resp.asString());
		Test_01();
	}
	
	//advanced: complex post - array
	//@Test
	public void Test_09(){
		
		InfoAdvanced infoAdv1 = new InfoAdvanced();
		infoAdv1.setEmail("test1@tester.com");
		infoAdv1.setPhone("111111");
		infoAdv1.setAddress("Address 1");
		
		InfoAdvanced infoAdv2 = new InfoAdvanced();
		infoAdv2.setEmail("test2@tester.com");
		infoAdv2.setPhone("222222");
		infoAdv2.setAddress("Address 2");
		
		PostsAdvanced postAdv1 = new PostsAdvanced();
		postAdv1.setId("22");
		postAdv1.setTitle("Title2");
		postAdv1.setAuthor("Author2");
		postAdv1.setInfoAdv(new InfoAdvanced[]{infoAdv1,infoAdv2});
		
		given().
		when().
		contentType(ContentType.JSON).
		body(postAdv1).
		post("http://localhost:3000/posts");
		
		Test_01();
	}
}
