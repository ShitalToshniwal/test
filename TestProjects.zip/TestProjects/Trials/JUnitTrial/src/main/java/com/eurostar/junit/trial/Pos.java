package com.eurostar.junit.trial;

public class Pos {
	public boolean validatePos(String pos){
		switch(pos){
			case "GBZXA":
			case "GBZXB":
			case "GBZXC":
			case "GBZXD":
				return true;
			default:
				return false;
		}
		
		
	}
}
