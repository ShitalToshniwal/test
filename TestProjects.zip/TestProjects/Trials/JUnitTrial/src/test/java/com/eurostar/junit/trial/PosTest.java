package com.eurostar.junit.trial;

import static org.junit.Assert.*;

import org.junit.Test;

public class PosTest {
	Pos pos1 = new Pos();
	
	@Test
	public void testValidatePos_Positive() {
		assertEquals(true, pos1.validatePos("GBZXA"));
		assertTrue("Failed", pos1.validatePos("GBZXB"));
		assertTrue("Failed", pos1.validatePos("GBZXC"));
		assertTrue("Failed", pos1.validatePos("GBZXD"));
		
	}
	
	@Test
	public void testValidatePos_Negative(){
		assertFalse("Failed", pos1.validatePos("GBZMB"));
	}

}
